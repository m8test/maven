package com.m8test.dokka.plugin

import org.jetbrains.dokka.CoreExtensions
import org.jetbrains.dokka.base.DokkaBase
import org.jetbrains.dokka.plugability.DokkaPlugin
import org.jetbrains.dokka.plugability.DokkaPluginApiPreview
import org.jetbrains.dokka.plugability.Extension
import org.jetbrains.dokka.plugability.PluginApiPreviewAcknowledgement
import org.jetbrains.dokka.renderers.Renderer

class CodeProviderDokkaPlugin : DokkaPlugin() {
    val myFilterExtension by extending { plugin<DokkaBase>().preMergeDocumentableTransformer providing ::CodeProviderFilterTransformer }
    val renderer: Extension<Renderer, *, *> by extending {
        CoreExtensions.renderer providing ::CodeProviderHtmlRenderer override plugin<DokkaBase>().htmlRenderer
    }

    @DokkaPluginApiPreview
    override fun pluginApiPreviewAcknowledgement() = PluginApiPreviewAcknowledgement
}