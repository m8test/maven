package com.m8test.dokka.plugin.transform

import com.m8test.dokka.plugin.KotlinFunctionInfo
import com.m8test.dokka.plugin.LanguageFunctionDefinition

/**
 * Description TODO
 *
 * @date 2024/12/08 12:05:46
 * @author M8Test, contact@m8test.com, https://m8test.com
 */
open class JvmFunctionTransformer(
    cp: (index: Int, paramName: String) -> String,
    cc: (index: Int, content: String) -> String,
    grb: () -> String
) : AbstractFunctionTransformer(cp = cp, cc = cc, grb = grb) {
    private fun addEmpty(index: Int, paramSize: Int): String {
        return """|{
            |    ${changeContent(index + paramSize, "")} 
            |${getRightBrackets()}""".trimMargin("|")
    }

    private fun Iterable<Int>.addParams(
        index: Int,
        paramSize: Int,
        changeParamIndex: (Int) -> Int,
        onParamAdd: () -> Unit
    ): String {
        var i = 0
        return joinToString(transform = {
            changeParam(
                index + paramSize + i,
                "v${changeParamIndex(it)}"
            ).also {
                i += 1
                onParamAdd()
            }
        })
    }

    override fun transform(kotlinFunctionInfo: KotlinFunctionInfo): LanguageFunctionDefinition {
        val fn: Int = kotlinFunctionInfo.parameterCount
        val index: Int = kotlinFunctionInfo.index
        val receiver: Boolean = kotlinFunctionInfo.hasReceiver
        var paramSize = 0
        fun addPs(start: Int): String {
            return """|{${
                (start..fn).addParams(
                    index,
                    paramSize,
                    { it - (start - 1) }) { paramSize += 1 }
            }->
            |    ${changeContent(index + paramSize, "").also { paramSize += 1 }}
            |${getRightBrackets()}""".trimMargin("|")
        }

        val parameterForm = when {
            fn == 0 -> addEmpty(index, paramSize).also { paramSize += 1 }
            receiver == false -> addPs(1)
            fn == 1 -> addEmpty(index, paramSize).also { paramSize += 1 }
            else -> addPs(2)
        }
        return LanguageFunctionDefinition(parameterForm, paramSize, null)
    }
}