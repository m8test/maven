package com.m8test.dokka.plugin

import com.m8test.dokka.plugin.editor.Suggestion
import com.m8test.dokka.plugin.idea.LiveTemplate
import com.m8test.dokka.plugin.vscode.CodeSnippet
import org.jetbrains.dokka.base.renderers.html.HtmlRenderer
import org.jetbrains.dokka.pages.RootPageNode
import org.jetbrains.dokka.plugability.DokkaContext

/**
 * Description TODO
 *
 * @date 2024/12/07 15:19:10
 * @author M8Test, contact@m8test.com, https://m8test.com
 */
class CodeProviderHtmlRenderer(private val dokkaContext: DokkaContext) :
    HtmlRenderer(dokkaContext) {
    override fun render(root: RootPageNode) {
        LiveTemplate.write(dokkaContext)
        CodeSnippet.write(dokkaContext)
        Suggestion.write(dokkaContext)
        super.render(root)
    }
}