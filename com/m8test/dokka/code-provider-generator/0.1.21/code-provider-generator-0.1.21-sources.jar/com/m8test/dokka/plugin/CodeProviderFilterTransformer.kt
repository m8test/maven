package com.m8test.dokka.plugin

import com.m8test.dokka.plugin.editor.Suggestion
import com.m8test.dokka.plugin.idea.LiveTemplate
import com.m8test.dokka.plugin.vscode.CodeSnippet
import org.jetbrains.dokka.base.transformers.documentables.SuppressedByConditionDocumentableFilterTransformer
import org.jetbrains.dokka.model.Annotations
import org.jetbrains.dokka.model.DClasslike
import org.jetbrains.dokka.model.Documentable
import org.jetbrains.dokka.model.WithSupertypes
import org.jetbrains.dokka.model.properties.WithExtraProperties
import org.jetbrains.dokka.plugability.DokkaContext

/**
 * Description TODO
 *
 * @date 2024/12/07 15:19:46
 * @author M8Test, contact@m8test.com, https://m8test.com
 */
class CodeProviderFilterTransformer(dokkaContext: DokkaContext) :
    SuppressedByConditionDocumentableFilterTransformer(dokkaContext) {
    private fun isKeep(d: Documentable): Boolean {
        val annotations: List<Annotations.Annotation> =
            (d as? WithExtraProperties<*>)
                ?.extra
                ?.allOfType<Annotations>()
                ?.flatMap { it.directAnnotations.values.flatten() }
                ?: emptyList()
        return annotations.any { isKeepAnnotation(it) }
    }

    override fun shouldBeSuppressed(d: Documentable): Boolean {
        val isKeep = isKeep(d)
        if (isKeep && d is DClasslike && d is WithSupertypes) {
            val packageName = d.dri.packageName
            val className = d.dri.classNames
            if (packageName != null && className != null) {
                val supertypes = d.supertypes.values.flatMap { it }.map {
                    val dri = it.typeConstructor.dri
                    dri.packageName + "." + dri.classNames
                }
                d.functions.filter { isKeep(it) }.forEach { f ->
                    CodeSnippet.generateSnippet(
                        packageName = packageName,
                        className = className,
                        d = f,
                        supertypes = supertypes
                    )
                    LiveTemplate.generateTemplate(
                        packageName = packageName,
                        className = className,
                        d = f,
                        supertypes = supertypes
                    )
                    Suggestion.generateSuggestion(
                        packageName = packageName,
                        className = className,
                        d = f,
                        supertypes = supertypes
                    )
                }
            }
        }
        return false
    }

    private fun isKeepAnnotation(annotation: Annotations.Annotation): Boolean {
        return annotation.dri.packageName == "com.m8test.dokka.annotation" && annotation.dri.classNames == "Keep"
    }
}