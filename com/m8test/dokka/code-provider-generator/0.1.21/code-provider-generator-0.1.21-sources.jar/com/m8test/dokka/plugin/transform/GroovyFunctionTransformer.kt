package com.m8test.dokka.plugin.transform

/**
 * Description TODO
 *
 * @date 2024/12/08 12:07:49
 * @author M8Test, contact@m8test.com, https://m8test.com
 */
class GroovyFunctionTransformer(
    cp: (index: Int, paramName: String) -> String,
    cc: (index: Int, content: String) -> String,
    grb: () -> String
) : JvmFunctionTransformer(cp = cp, cc = cc, grb = grb)