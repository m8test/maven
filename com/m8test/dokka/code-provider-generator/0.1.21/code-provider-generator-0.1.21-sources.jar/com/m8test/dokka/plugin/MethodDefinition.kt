package com.m8test.dokka.plugin

import org.jetbrains.dokka.links.DRI
import org.jetbrains.dokka.model.Annotations
import org.jetbrains.dokka.model.Bound
import org.jetbrains.dokka.model.DFunction
import org.jetbrains.dokka.model.DParameter
import org.jetbrains.dokka.model.DefinitelyNonNullable
import org.jetbrains.dokka.model.Documentable
import org.jetbrains.dokka.model.FunctionalTypeConstructor
import org.jetbrains.dokka.model.GenericTypeConstructor
import org.jetbrains.dokka.model.JavaVisibility
import org.jetbrains.dokka.model.KotlinVisibility
import org.jetbrains.dokka.model.PrimitiveJavaType
import org.jetbrains.dokka.model.TypeAliased
import org.jetbrains.dokka.model.TypeParameter
import org.jetbrains.dokka.model.properties.WithExtraProperties

/**
 * Description TODO
 *
 * @date 2024/12/07 15:58:01
 * @author M8Test, contact@m8test.com, https://m8test.com
 */
data class MethodDefinition(
    val packageName: String,
    val className: String,
    val methodName: String,
    val document: String,
    val supertypes: List<String>,
    val parameters: List<ParameterDefinition> // name type receiver
) {
    companion object {
        private val PUBLIC_VISIBILITIES = listOf<org.jetbrains.dokka.model.Visibility>(
            KotlinVisibility.Public,
            JavaVisibility.Public
        )

        private fun isFunctionPublic(dFunction: DFunction): Boolean {
            return dFunction.visibility.values.any { PUBLIC_VISIBILITIES.contains(it) }
        }

        fun from(
            packageName: String,
            className: String,
            supertypes: List<String>,
            d: Documentable
        ): MethodDefinition? {
            // 如果不是方法或者是构造方法就不需要生成snippet
            if (d !is DFunction || d.isConstructor || !isFunctionPublic(d)) return null
            val doc = DokkaTransformer.getDescription(d)
            return from(
                packageName = packageName,
                className = className,
                supertypes = supertypes,
                function = d,
                document = doc
            )
        }

        private fun from(
            packageName: String,
            className: String,
            document: String,
            supertypes: List<String>,
            function: DFunction
        ): MethodDefinition {
            return MethodDefinition(
                packageName = packageName,
                className = className,
                document = document,
                methodName = function.name,
                supertypes = supertypes,
                parameters = getParameters(function)
            )
        }

        private fun getExtensionFunctionType(parameter: DParameter): Boolean {
            val type = parameter.type
            if (type is FunctionalTypeConstructor) {
                return (type as WithExtraProperties<*>)
                    .extra
                    .allOfType<Annotations>()
                    .flatMap { it.directAnnotations.values.flatten() }.any {
                        it.dri.packageName == "kotlin" && it.dri.classNames == "ExtensionFunctionType"
                    }
            }
            return false
        }

        private fun transformBound(bound: Bound): String {
            return when (bound) {
                is DefinitelyNonNullable -> transformBound(bound)
                is GenericTypeConstructor, is FunctionalTypeConstructor -> getFullClassName(bound.dri)
                is TypeParameter -> getFullClassName(bound.dri)
                is PrimitiveJavaType -> bound.name
                is org.jetbrains.dokka.model.Nullable -> transformBound(bound.inner)
                is TypeAliased -> transformBound(bound.inner)
                else -> bound.toString()
            }
        }

        private fun getFullClassName(dri: DRI): String {
            return dri.packageName.orEmpty() + "." + dri.classNames.orEmpty()
        }

        private fun getParameters(function: DFunction): List<ParameterDefinition> {
            if (function.parameters.isEmpty()) return emptyList()
            return function.parameters.map { item ->
                ParameterDefinition(
                    item.name?.toString() ?: "",
                    transformBound(item.type),
                    getExtensionFunctionType(item)
                )
            }
        }
    }
}