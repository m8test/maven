package com.m8test.dokka.plugin.transform

/**
 * Description TODO
 *
 * @date 2024/12/08 15:08:31
 * @author M8Test, contact@m8test.com, https://m8test.com
 */
abstract class AbstractFunctionTransformer(
    private val cp: (index: Int, paramName: String) -> String,
    private val cc: (index: Int, content: String) -> String,
    private val grb: () -> String
) : FunctionTransformer {
    fun changeParam(index: Int, paramName: String): String {
        return cp(index, paramName)
    }

    fun changeContent(index: Int, content: String): String {
        return cc(index, content)
    }

    fun getRightBrackets(): String {
        return grb()
    }
}