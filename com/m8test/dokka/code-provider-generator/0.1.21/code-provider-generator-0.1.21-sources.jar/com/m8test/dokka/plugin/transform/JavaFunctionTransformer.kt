package com.m8test.dokka.plugin.transform

import com.m8test.dokka.plugin.KotlinFunctionInfo
import com.m8test.dokka.plugin.LanguageFunctionDefinition

/**
 * Description TODO
 *
 * @date 2024/12/08 12:08:58
 * @author M8Test, contact@m8test.com, https://m8test.com
 */
class JavaFunctionTransformer(
    cp: (index: Int, paramName: String) -> String,
    cc: (index: Int, content: String) -> String,
    grb: () -> String
) : AbstractFunctionTransformer(cp = cp, cc = cc, grb = grb) {
    override fun transform(kotlinFunctionInfo: KotlinFunctionInfo): LanguageFunctionDefinition {
        val fn: Int = kotlinFunctionInfo.parameterCount
        val index = kotlinFunctionInfo.index
        var paramSize = 0
        val parameterForm = """
                    |new Function$fn() { 
                    |    public Object invoke(${
            (1..fn).joinToString(transform = {
                "Object " + changeParam(
                    index + paramSize,
                    "v$it"
                ).also { paramSize += 1 }
            })
        }){
                    |        ${
            changeContent(index + paramSize, "").also { paramSize += 1 }
        }                        
                    |        return null;
                    |    ${getRightBrackets()}
                    |${getRightBrackets()}""".trimMargin("|")
        return LanguageFunctionDefinition(parameterForm, paramSize, null)
    }
}