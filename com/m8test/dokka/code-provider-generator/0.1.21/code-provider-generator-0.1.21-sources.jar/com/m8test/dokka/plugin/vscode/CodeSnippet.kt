package com.m8test.dokka.plugin.vscode

import com.google.gson.GsonBuilder
import com.m8test.dokka.plugin.CodeProvider
import com.m8test.dokka.plugin.Language
import com.m8test.dokka.plugin.MethodDefinition
import com.m8test.dokka.plugin.transform.GroovyFunctionTransformer
import com.m8test.dokka.plugin.transform.JavaFunctionTransformer
import com.m8test.dokka.plugin.transform.JavaScriptFunctionTransformer
import com.m8test.dokka.plugin.transform.KotlinFunctionTransformer
import com.m8test.dokka.plugin.transform.LuaFunctionTransformer
import com.m8test.dokka.plugin.transform.PhpFunctionTransformer
import com.m8test.dokka.plugin.transform.PythonFunctionTransformer
import com.m8test.dokka.plugin.transform.RubyFunctionTransformer
import org.jetbrains.dokka.links.Callable
import org.jetbrains.dokka.model.Documentable
import org.jetbrains.dokka.plugability.DokkaContext
import java.io.File

/**
 * Description TODO
 *
 * @date 2024/12/06 19:13:07
 * @author M8Test, contact@m8test.com, https://m8test.com
 */
data class CodeSnippet(
    override val prefix: String,
    override val body: String,
    override val description: String,
    override val scope: String
) : CodeProvider {
    companion object {
        private val prettyGson = GsonBuilder().setPrettyPrinting().create()
        fun write(dokkaContext: DokkaContext) {
            val p = dokkaContext.configuration.outputDir.parent
            val dir = File(p, "snippets/vscode").apply { mkdirs() }
            codeSnippets.forEach { (languageName, codeSnippets) ->
                File(dir, "m8test-${languageName}.code-snippets").apply {
                    writeText(prettyGson.toJson(codeSnippets))
                }
            }
        }

        fun addIndex(index: Int, content: String): String {
            if (content.isBlank()) return "\$${index}"
            return "\${${index}:$content}"
        }

        fun generateSnippet(
            packageName: String,
            className: String,
            supertypes: List<String>,
            d: Documentable
        ) {
            val md = MethodDefinition.from(
                supertypes = supertypes,
                packageName = packageName,
                className = className,
                d = d
            ) ?: return
            val callable = d.dri.callable ?: return
            languages.forEach { language ->
                getSnippet(
                    md = md,
                    language = language,
                    callable = callable,
                    hasClassName = true
                )?.let { snippet ->
                    codeSnippets.getOrPut(language.name) { mutableMapOf() }
                        .put(snippet.prefix, snippet)
                }
                getSnippet(
                    md = md,
                    language = language,
                    callable = callable,
                    hasClassName = false
                )?.let { snippet ->
                    codeSnippets.getOrPut(language.name) { mutableMapOf() }
                        .put("M8Test" + md.className + snippet.prefix, snippet)
                }
            }
        }

        private fun getSnippet(
            md: MethodDefinition,
            language: Language,
            callable: Callable,
            hasClassName: Boolean
        ): CodeSnippet? {
            return CodeProvider.getCodeProvider(
                md = md,
                language = language,
                callable = callable,
                hasClassName = hasClassName
            ) { prefix, body, description, scope ->
                CodeSnippet(
                    description = description,
                    body = body,
                    prefix = prefix,
                    scope = scope
                )
            }
        }

        private val cp: (Int, String) -> String = { index, paramName -> addIndex(index, paramName) }
        private val cc: (Int, String) -> String = { index, content -> addIndex(index, content) }
        private val grb: () -> String = { """\}""" }
        private val codeSnippets = mutableMapOf<String, MutableMap<String, CodeSnippet>>()
        private val languages = listOf(
            Language(
                prefix = "\\$",
                name = "groovy",
                callString = ".",
                extensions = setOf("groovy"),
                transformer = VscodeTransformer(
                    GroovyFunctionTransformer(
                        cp = cp,
                        cc = cc,
                        grb = grb
                    )
                )
            ),
            Language(
                prefix = "\\$",
                name = "java",
                callString = ".",
                expressionSuffix = ";",
                extensions = setOf("java", "javas"),
                transformer = VscodeTransformer(
                    JavaFunctionTransformer(
                        cp = cp,
                        cc = cc,
                        grb = grb
                    )
                )
            ),
            Language(
                prefix = "\\$",
                name = "javascript",
                callString = ".",
                extensions = setOf("js"),
                transformer = VscodeTransformer(
                    JavaScriptFunctionTransformer(
                        cp = cp,
                        cc = cc,
                        grb = grb
                    )
                )
            ),
            Language(
                prefix = "_",
                name = "kotlin",
                callString = ".",
                extensions = setOf("kts", "kt"),
                transformer = VscodeTransformer(
                    KotlinFunctionTransformer(
                        cp = cp,
                        cc = cc,
                        grb = grb
                    )
                )
            ),
            Language(
                prefix = "_",
                name = "lua",
                callString = ":",
                extensions = setOf("lua"),
                transformer = VscodeTransformer(LuaFunctionTransformer(cp = cp, cc = cc, grb = grb))
            ),
            Language(
                prefix = "\\$",
                name = "php",
                callString = "->",
                expressionSuffix = ";",
                extensions = setOf("php"),
                transformer = VscodeTransformer(PhpFunctionTransformer(cp = cp, cc = cc, grb = grb))
            ),
            Language(
                prefix = "_",
                name = "python",
                callString = ".",
                extensions = setOf("py"),
                transformer = VscodeTransformer(
                    PythonFunctionTransformer(
                        cp = cp,
                        cc = cc,
                        grb = grb,
                        tfn = { it }
                    )
                )
            ),
            Language(
                prefix = "\\$",
                name = "ruby",
                callString = ".",
                extensions = setOf("rb"),
                transformer = VscodeTransformer(
                    RubyFunctionTransformer(
                        cp = cp,
                        cc = cc,
                        grb = grb
                    )
                )
            ),
        )
    }
}