package com.m8test.dokka.plugin.idea

import com.m8test.dokka.plugin.KotlinFunctionInfo
import com.m8test.dokka.plugin.MethodDefinition
import com.m8test.dokka.plugin.transform.AbstractCodeProviderTransformer
import com.m8test.dokka.plugin.transform.FunctionTransformer
import org.jetbrains.dokka.links.TypeReference

/**
 * Description TODO
 *
 * @date 2024/12/09 10:48:37
 * @author M8Test, contact@m8test.com, https://m8test.com
 */
class IdeaTransformer(override val transformer: FunctionTransformer) :
    AbstractCodeProviderTransformer() {
    override val transformPrefix: (index: Int, TypeReference) -> String = ::transformTypeReference
    override val transformBody: (MethodDefinition) -> Pair<String, String> =
        { item -> transformBody(item, transformer) }

    private fun transformBody(md: MethodDefinition, tf: FunctionTransformer): Pair<String, String> {
        var index = 1
        val sb = StringBuilder()
        val body = md.parameters.mapIndexed { i, p ->
            getFunctionNumber(p.className)?.let {
                val kfi = KotlinFunctionInfo(
                    isLastParameter = i == md.parameters.lastIndex,
                    parameterCount = it,
                    index = index,
                    hasReceiver = p.hasReceiver,
                    name = p.name
                )
                val lfd = tf.transform(kfi)
                index += lfd.useIndexCount
                lfd.definition?.let { d -> sb.append(d).append("\n") }
                lfd.parameterForm
            }
            val r = LiveTemplate.addParam(p.name)
            index += 1
            r
        }.joinToString()
        return body to sb.toString()
    }
}