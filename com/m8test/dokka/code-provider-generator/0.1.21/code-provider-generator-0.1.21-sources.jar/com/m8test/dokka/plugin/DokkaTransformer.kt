package com.m8test.dokka.plugin

import org.jetbrains.dokka.model.Documentable
import org.jetbrains.dokka.model.doc.CustomDocTag
import org.jetbrains.dokka.model.doc.Description
import org.jetbrains.dokka.model.doc.DocTag
import org.jetbrains.dokka.model.doc.DocumentationLink
import org.jetbrains.dokka.model.doc.P
import org.jetbrains.dokka.model.doc.Param
import org.jetbrains.dokka.model.doc.Return
import org.jetbrains.dokka.model.doc.TagWrapper
import org.jetbrains.dokka.model.doc.Text

/**
 * Description TODO
 *
 * @date 2024/12/09 10:01:34
 * @author M8Test, contact@m8test.com, https://m8test.com
 */
object DokkaTransformer {
    fun getDescription(d: Documentable): String {
        val descriptions = getDescriptions(d)
        return if (descriptions.isEmpty()) "" else descriptions.last()
    }

    private fun getDescriptions(d: Documentable): List<String> {
        val list = mutableListOf<String>()
        d.documentation.values.forEach { v ->
            val sb = StringBuilder()
            v.children.forEach { c ->
                sb.append(transformTagWrapper(tagWrapper = c))
            }
            list.add(sb.toString())
        }
        return list
    }

    private fun transformTagWrapper(tagWrapper: TagWrapper): String {
        return when (tagWrapper) {
            is Description -> tagWrapper.children.joinToString(
                separator = "\n",
                postfix = "\n",
                transform = { transformDocTag(it) })

            is Param -> "\n@param ${tagWrapper.name} " + tagWrapper.children.joinToString(
                separator = "\n",
                transform = { transformDocTag(it) })

            is Return -> "\n@return " + tagWrapper.children.joinToString(
                separator = "\n",
                transform = { transformDocTag(it) })

            else -> tagWrapper.toString()
        }
    }

    private fun transformDocTag(docTag: DocTag): String {
        return when (docTag) {
            is CustomDocTag, is P, is DocumentationLink -> docTag.children.joinToString(
                separator = "",
                transform = { transformDocTag(it) })

            is Text -> docTag.body

            else -> docTag.toString()
        }
    }
}