package com.m8test.dokka.plugin

import com.m8test.dokka.plugin.transform.CodeProviderTransformer

/**
 * Description TODO
 *
 * @date 2024/12/06 19:28:31
 * @author M8Test, contact@m8test.com, https://m8test.com
 */
data class Language(
    /**
     * 语言变量的前缀, 例如groovy是$, kotlin是_
     */
    val prefix: String,
    val callString: String,
    val name: String,
    val expressionSuffix: String = "",
    val extensions: Set<String>,
    val transformer: CodeProviderTransformer
)