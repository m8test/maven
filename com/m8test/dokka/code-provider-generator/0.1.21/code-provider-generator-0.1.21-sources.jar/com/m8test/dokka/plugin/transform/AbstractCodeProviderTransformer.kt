package com.m8test.dokka.plugin.transform

import org.jetbrains.dokka.links.Nullable
import org.jetbrains.dokka.links.TypeConstructor
import org.jetbrains.dokka.links.TypeParam
import org.jetbrains.dokka.links.TypeReference

/**
 * Description TODO
 *
 * @date 2024/12/09 10:32:32
 * @author M8Test, contact@m8test.com, https://m8test.com
 */
abstract class AbstractCodeProviderTransformer : CodeProviderTransformer {
    protected fun transformTypeReference(index: Int, typeReference: TypeReference): String {
        return when (typeReference) {
            is Nullable -> transformTypeReference(index, typeReference.wrapped)
            is TypeConstructor -> typeReference.fullyQualifiedName
            is TypeParam -> "T$index"
            else -> typeReference.toString()
        }
    }

    companion object {
        fun getFunctionNumber(functionName: String): Int? {
            val number = functionName.replace("kotlin.Function", "")
            return try {
                number.toInt()
            } catch (e: Throwable) {
                null
            }
        }
    }
}