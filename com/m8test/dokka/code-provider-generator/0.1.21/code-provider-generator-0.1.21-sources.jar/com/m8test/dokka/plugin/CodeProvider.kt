package com.m8test.dokka.plugin

import org.jetbrains.dokka.links.Callable

/**
 * Description TODO
 *
 * @date 2024/12/09 09:37:04
 * @author M8Test, contact@m8test.com, https://m8test.com
 */
interface CodeProvider {
    val prefix: String
    val body: String
    val description: String
    val scope: String

    companion object {
        private fun getPrefix(
            className: String,
            callable: Callable,
            language: Language,
            hasClassName: Boolean
        ): String {
            return "${if (!hasClassName) ".M8Test" else ""}${className}${language.callString}${callable.name}(${
                callable.params.mapIndexed(language.transformer.transformPrefix).joinToString()
            })${language.expressionSuffix}"
        }

        fun <T : CodeProvider> getCodeProvider(
            md: MethodDefinition,
            language: Language,
            callable: Callable,
            hasClassName: Boolean,
            getter: (prefix: String, body: String, description: String, scope: String) -> T
        ): T? {
            if (hasClassName && !md.supertypes.contains("com.m8test.script.core.api.component.Variable")) return null
            if (!hasClassName && md.supertypes.contains("com.m8test.script.core.api.component.Variable")) return null
            val doc = md.document
            val className = md.className
            return getter(
                getPrefix(
                    className = className,
                    callable = callable,
                    language = language,
                    hasClassName = hasClassName
                ),
                getBody(
                    className = className,
                    md = md,
                    language = language,
                    hasClassName = hasClassName
                ),
                if (hasClassName) doc else "$className${language.callString}${md.methodName}\n$doc",
                language.name
            )
        }

        private fun getBody(
            className: String,
            md: MethodDefinition,
            language: Language,
            hasClassName: Boolean
        ): String {
            val (body, definition) = language.transformer.transformBody(md)
            return (if (definition.isNotBlank()) definition else "") + """
            |${if (hasClassName) language.prefix + className.replaceFirstChar { it.lowercase() } else ""}${language.callString}${md.methodName}(${
                body
            })${language.expressionSuffix}""".trimMargin("|")
        }
    }
}