package com.m8test.dokka.plugin.editor

import com.google.gson.GsonBuilder
import com.m8test.dokka.plugin.CodeProvider
import com.m8test.dokka.plugin.Language
import com.m8test.dokka.plugin.MethodDefinition
import com.m8test.dokka.plugin.transform.GroovyFunctionTransformer
import com.m8test.dokka.plugin.transform.JavaFunctionTransformer
import com.m8test.dokka.plugin.transform.JavaScriptFunctionTransformer
import com.m8test.dokka.plugin.transform.KotlinFunctionTransformer
import com.m8test.dokka.plugin.transform.LuaFunctionTransformer
import com.m8test.dokka.plugin.transform.PhpFunctionTransformer
import com.m8test.dokka.plugin.transform.PythonFunctionTransformer
import com.m8test.dokka.plugin.transform.RubyFunctionTransformer
import org.jetbrains.dokka.links.Callable
import org.jetbrains.dokka.model.Documentable
import org.jetbrains.dokka.plugability.DokkaContext
import java.io.File

/**
 * Description TODO
 *
 * @date 2024/12/16 19:21:11
 * @author M8Test, contact@m8test.com, https://m8test.com
 */
data class Suggestion(
    override val description: String,
    override val prefix: String,
    override val body: String,
    override val scope: String,
    val prefixWithoutCallString: String
) : CodeProvider {
    companion object {
        private val prettyGson = GsonBuilder().setPrettyPrinting().create()
        fun write(dokkaContext: DokkaContext) {
            val p = dokkaContext.configuration.outputDir.parent
            val dir = File(p, "snippets/editor").apply { mkdirs() }
            codeSnippets.forEach { (language, codeSnippets) ->
                File(dir, "m8test-${language.name}.json").apply {
                    writeText(prettyGson.toJson(codeSnippets))
                }
            }
        }

        private val cp: (Int, String) -> String = { _, paramName -> paramName }
        private val cc: (Int, String) -> String = { _, content -> content }
        private val grb: () -> String = { "}" }

        private val languages = listOf(
            Language(
                prefix = "$",
                name = "groovy",
                callString = ".",
                extensions = setOf("groovy"),
                transformer = EditorTransformer(
                    GroovyFunctionTransformer(
                        cp = cp,
                        cc = cc,
                        grb = grb
                    )
                )
            ),
            Language(
                prefix = "$",
                name = "java",
                callString = ".",
                expressionSuffix = ";",
                extensions = setOf("java", "javas"),
                transformer = EditorTransformer(
                    JavaFunctionTransformer(
                        cp = cp,
                        cc = cc,
                        grb = grb
                    )
                )
            ),
            Language(
                prefix = "$",
                name = "javascript",
                callString = ".",
                extensions = setOf("js"),
                transformer = EditorTransformer(
                    JavaScriptFunctionTransformer(
                        cp = cp,
                        cc = cc,
                        grb = grb
                    )
                )
            ),
            Language(
                prefix = "_",
                name = "kotlin",
                callString = ".",
                extensions = setOf("kts", "kt"),
                transformer = EditorTransformer(
                    KotlinFunctionTransformer(
                        cp = cp,
                        cc = cc,
                        grb = grb
                    )
                )
            ),
            Language(
                prefix = "_",
                name = "lua",
                callString = ":",
                extensions = setOf("lua"),
                transformer = EditorTransformer(LuaFunctionTransformer(cp = cp, cc = cc, grb = grb))
            ),
            Language(
                prefix = "$",
                name = "php",
                callString = "->",
                expressionSuffix = ";",
                extensions = setOf("php"),
                transformer = EditorTransformer(PhpFunctionTransformer(cp = cp, cc = cc, grb = grb))
            ),
            Language(
                prefix = "_",
                name = "python",
                callString = ".",
                extensions = setOf("py"),
                transformer = EditorTransformer(
                    PythonFunctionTransformer(
                        cp = cp,
                        cc = cc,
                        grb = grb,
                        tfn = { it }
                    )
                )
            ),
            Language(
                prefix = "$",
                name = "ruby",
                callString = ".",
                extensions = setOf("rb"),
                transformer = EditorTransformer(
                    RubyFunctionTransformer(
                        cp = cp,
                        cc = cc,
                        grb = grb
                    )
                )
            ),
        )

        private val codeSnippets = mutableMapOf<Language, MutableMap<String, Suggestion>>()

        private fun getSuggestion(
            md: MethodDefinition,
            language: Language,
            callable: Callable,
            hasClassName: Boolean
        ): Suggestion? {
            return CodeProvider.getCodeProvider(
                md = md,
                language = language,
                callable = callable,
                hasClassName = hasClassName
            ) { prefix, body, description, scope ->
                Suggestion(
                    description = description,
                    body = body,
                    prefix = prefix,
                    scope = scope,
                    prefixWithoutCallString = prefix.replace(language.callString, "")
                )
            }
        }

        fun generateSuggestion(
            packageName: String,
            className: String,
            supertypes: List<String>,
            d: Documentable
        ) {
            val md = MethodDefinition.from(
                supertypes = supertypes,
                packageName = packageName,
                className = className,
                d = d
            ) ?: return
            val callable = d.dri.callable ?: return
            languages.forEach { language ->
                getSuggestion(
                    md = md,
                    language = language,
                    callable = callable,
                    hasClassName = true
                )?.let { snippet ->
                    codeSnippets.getOrPut(language) { mutableMapOf() }.put(snippet.prefix, snippet)
                }
                getSuggestion(
                    md = md,
                    language = language,
                    callable = callable,
                    hasClassName = false
                )?.let { snippet ->
                    codeSnippets.getOrPut(language) { mutableMapOf() }
                        .put("M8Test" + md.className + snippet.prefix, snippet)
                }
            }
        }
    }
}