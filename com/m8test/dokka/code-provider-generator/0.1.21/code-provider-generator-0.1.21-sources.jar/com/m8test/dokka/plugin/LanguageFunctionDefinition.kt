package com.m8test.dokka.plugin

/**
 * Description TODO
 *
 * @date 2024/12/08 09:47:06
 * @author M8Test, contact@m8test.com, https://m8test.com
 */
data class LanguageFunctionDefinition(
    /**
     * 在方法中显示的字符串, 例如 python 是 fn1, 然后对应的 [definition] 为
     * def fn1():
     *    pass
     * 在 groovy 中直接就是 {v1->}, 而 [definition] 为 null
     */
    val parameterForm: String,
    /**
     * 使用了多少个 index, ${1} ,${2} 这种
     */
    val useIndexCount: Int,
    /**
     * 有可能为null, 因为可以直接使用 [parameterForm], 已经足够
     */
    val definition: String?
)