package com.m8test.dokka.plugin

/**
 * Description TODO
 *
 * @date 2024/12/08 09:32:51
 * @author M8Test, contact@m8test.com, https://m8test.com
 */
data class KotlinFunctionInfo(
    /**
     * 是不是最后一个参数, 例如, 如果是 ruby 语言, true 表示不需要添加 lambda, false 需要添加 lambda
     */
    val isLastParameter: Boolean,
    /**
     * 参数个数
     */
    val parameterCount: Int,
    /**
     * 位于方法哪个位置
     */
    val index: Int,
    /**
     * 是否为 T.(), 如果是true就是T.(),false是(T)
     */
    val hasReceiver: Boolean,
    /**
     * 参数名
     */
    val name: String
)