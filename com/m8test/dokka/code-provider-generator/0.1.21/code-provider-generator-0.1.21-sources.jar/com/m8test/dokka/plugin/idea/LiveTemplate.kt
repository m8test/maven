package com.m8test.dokka.plugin.idea

import com.m8test.dokka.plugin.CodeProvider
import com.m8test.dokka.plugin.KotlinFunctionInfo
import com.m8test.dokka.plugin.Language
import com.m8test.dokka.plugin.MethodDefinition
import com.m8test.dokka.plugin.transform.AbstractCodeProviderTransformer
import com.m8test.dokka.plugin.transform.GroovyFunctionTransformer
import com.m8test.dokka.plugin.transform.JavaFunctionTransformer
import com.m8test.dokka.plugin.transform.JavaScriptFunctionTransformer
import com.m8test.dokka.plugin.transform.KotlinFunctionTransformer
import com.m8test.dokka.plugin.transform.LuaFunctionTransformer
import com.m8test.dokka.plugin.transform.PhpFunctionTransformer
import com.m8test.dokka.plugin.transform.PythonFunctionTransformer
import com.m8test.dokka.plugin.transform.RubyFunctionTransformer
import org.jetbrains.dokka.links.Callable
import org.jetbrains.dokka.model.Documentable
import org.jetbrains.dokka.plugability.DokkaContext
import org.redundent.kotlin.xml.xml
import java.io.File

/**
 * Description TODO
 *
 * @date 2024/12/08 18:24:06
 * @author M8Test, contact@m8test.com, https://m8test.com
 */
data class LiveTemplate(
    override val prefix: String,
    override val body: String,
    override val description: String,
    override val scope: String,
    val methodDefinition: MethodDefinition,
) : CodeProvider {
    companion object {
        fun addParam(name: String): String {
            return "$$name$"
        }

        private fun replaceNextLine(source: String): String {
            return source.replace("\n", "&#10;")
        }

        private fun replaceTemplate(t: LiveTemplate): LiveTemplate {
            return t.copy(
                prefix = replaceNextLine(t.prefix),
                description = replaceNextLine(t.description),
                body = replaceNextLine(t.body),
            )
        }

        fun generateLiveTemplatesXml(
            language: Language,
            snippets: Map<String, LiveTemplate>
        ): String {
            val languageName = language.name
            return xml("templateSet") {
                attribute("group", "M8Test-$languageName")
                snippets.forEach { (name, t) ->
                    val template = replaceTemplate(t)
                    "template" {
                        attribute("name", template.prefix)
                        attribute("value", template.body)
                        attribute("description", template.description)
                        attribute("toReformat", "false")
                        attribute("toShortenFQNames", "true")
                        val parameters = template.methodDefinition.parameters
                        parameters.forEachIndexed { index, parameter ->
                            "variable" {
                                val fn =
                                    AbstractCodeProviderTransformer.getFunctionNumber(parameter.className)
                                attribute("name", parameter.name)
                                attribute("expression", "")
                                attribute(
                                    name = "defaultValue",
                                    value = """
                                    "${
                                        fn?.let {
                                            language.transformer.transformer.transform(
                                                kotlinFunctionInfo = KotlinFunctionInfo(
                                                    isLastParameter = index == parameters.lastIndex,
                                                    parameterCount = it,
                                                    index = index,
                                                    hasReceiver = parameter.hasReceiver,
                                                    name = parameter.name
                                                )
                                            ).parameterForm
                                        }
                                            ?.let { s -> if (s == addParam(parameter.name)) null else s }
                                            ?: parameter.name
                                    }"
                                """.trimIndent()
                                )
                                attribute("alwaysStopAt", "true")
                            }
                        }

                        "context" {
                            "option" {
                                attribute("name", ideaLanguageNames[languageName]!!)
                                attribute("value", "true")
                            }
                        }
                    }
                }
            }.toString().replace("&amp;#10;", "&#10;")
        }

        private val ideaLanguageNames = mutableMapOf<String, String>(
            "groovy" to "GROOVY",
            "java" to "JAVA CODE",
            "javascript" to "JAVA SCRIPT",
            "kotlin" to "KOTLIN",
            "lua" to "LUA",
            "php" to "PHP",
            "python" to "Python",
            "ruby" to "RUBY"
        )

        private val codeSnippets = mutableMapOf<Language, MutableMap<String, LiveTemplate>>()

        private fun getLiveTemplate(
            md: MethodDefinition,
            language: Language,
            callable: Callable,
            hasClassName: Boolean
        ): LiveTemplate? {
            return CodeProvider.getCodeProvider(
                md = md,
                language = language,
                callable = callable,
                hasClassName = hasClassName
            ) { prefix, body, description, scope ->
                LiveTemplate(
                    description = addQuotes(description),
                    body = addQuotes(body),
                    prefix = addQuotes(prefix),
                    scope = addQuotes(scope),
                    methodDefinition = md
                )
            }
        }

        private fun addQuotes(source: String): String {
            return source.replace("\"", "\\\"")
        }

        fun generateTemplate(
            packageName: String,
            className: String,
            supertypes: List<String>,
            d: Documentable
        ) {
            val md = MethodDefinition.from(
                supertypes = supertypes,
                packageName = packageName,
                className = className,
                d = d
            ) ?: return
            val callable = d.dri.callable ?: return
            languages.forEach { language ->
                getLiveTemplate(
                    md = md,
                    language = language,
                    callable = callable,
                    hasClassName = true
                )?.let { snippet ->
                    codeSnippets.getOrPut(language) { mutableMapOf() }.put(snippet.prefix, snippet)
                }
                getLiveTemplate(
                    md = md,
                    language = language,
                    callable = callable,
                    hasClassName = false
                )?.let { snippet ->
                    codeSnippets.getOrPut(language) { mutableMapOf() }
                        .put("M8Test" + md.className + snippet.prefix, snippet)
                }
            }
        }

        fun write(dokkaContext: DokkaContext) {
            codeSnippets.forEach { (language, snippets) ->
                val parent = dokkaContext.configuration.outputDir.parent
                val dir = File(parent, "snippets/idea").apply { mkdirs() }
                val xml = generateLiveTemplatesXml(language, snippets)
                File(dir, "M8Test-${language.name}.xml").writeText(xml)
            }
        }

        private val cp: (Int, String) -> String = { _, paramName -> paramName }
        private val cc: (Int, String) -> String = { _, content -> content }
        private val grb: () -> String = { "}" }

        private val languages = listOf(
            Language(
                prefix = "$",
                name = "groovy",
                callString = ".",
                extensions = setOf("groovy"),
                transformer = IdeaTransformer(
                    GroovyFunctionTransformer(
                        cp = cp,
                        cc = cc,
                        grb = grb
                    )
                )
            ),
            Language(
                prefix = "$",
                name = "java",
                callString = ".",
                expressionSuffix = ";",
                extensions = setOf("java", "javas"),
                transformer = IdeaTransformer(JavaFunctionTransformer(cp = cp, cc = cc, grb = grb))
            ),
            Language(
                prefix = "$",
                name = "javascript",
                callString = ".",
                extensions = setOf("js"),
                transformer = IdeaTransformer(
                    JavaScriptFunctionTransformer(
                        cp = cp,
                        cc = cc,
                        grb = grb
                    )
                )
            ),
            Language(
                prefix = "_",
                name = "kotlin",
                callString = ".",
                extensions = setOf("kts", "kt"),
                transformer = IdeaTransformer(
                    KotlinFunctionTransformer(
                        cp = cp,
                        cc = cc,
                        grb = grb
                    )
                )
            ),
            Language(
                prefix = "_",
                name = "lua",
                callString = ":",
                extensions = setOf("lua"),
                transformer = IdeaTransformer(LuaFunctionTransformer(cp = cp, cc = cc, grb = grb))
            ),
            Language(
                prefix = "$",
                name = "php",
                callString = "->",
                expressionSuffix = ";",
                extensions = setOf("php"),
                transformer = IdeaTransformer(PhpFunctionTransformer(cp = cp, cc = cc, grb = grb))
            ),
            Language(
                prefix = "_",
                name = "python",
                callString = ".",
                extensions = setOf("py"),
                transformer = IdeaTransformer(
                    PythonFunctionTransformer(
                        cp = cp,
                        cc = cc,
                        grb = grb,
                        tfn = { """$$it$""" }
                    )
                )
            ),
            Language(
                prefix = "$",
                name = "ruby",
                callString = ".",
                extensions = setOf("rb"),
                transformer = IdeaTransformer(RubyFunctionTransformer(cp = cp, cc = cc, grb = grb))
            ),
        )
    }
}