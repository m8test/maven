package com.m8test.dokka.plugin.transform

import com.m8test.dokka.plugin.MethodDefinition
import org.jetbrains.dokka.links.TypeReference

/**
 * Description TODO
 *
 * @date 2024/12/09 10:32:32
 * @author M8Test, contact@m8test.com, https://m8test.com
 */
interface CodeProviderTransformer {
    val transformer: FunctionTransformer
    val transformPrefix: (index: Int, TypeReference) -> String
    val transformBody: (MethodDefinition) -> Pair<String, String>
}