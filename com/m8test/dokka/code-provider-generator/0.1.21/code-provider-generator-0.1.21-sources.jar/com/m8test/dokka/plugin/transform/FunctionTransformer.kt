package com.m8test.dokka.plugin.transform

import com.m8test.dokka.plugin.KotlinFunctionInfo
import com.m8test.dokka.plugin.LanguageFunctionDefinition

/**
 * Description TODO
 *
 * @date 2024/12/08 12:03:01
 * @author M8Test, contact@m8test.com, https://m8test.com
 */
interface FunctionTransformer {
    fun transform(kotlinFunctionInfo: KotlinFunctionInfo): LanguageFunctionDefinition
}