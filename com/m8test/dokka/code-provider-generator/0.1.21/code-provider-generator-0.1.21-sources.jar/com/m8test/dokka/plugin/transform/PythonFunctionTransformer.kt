package com.m8test.dokka.plugin.transform

import com.m8test.dokka.plugin.KotlinFunctionInfo
import com.m8test.dokka.plugin.LanguageFunctionDefinition

/**
 * Description TODO
 *
 * @date 2024/12/08 12:13:16
 * @author M8Test, contact@m8test.com, https://m8test.com
 */
class PythonFunctionTransformer(
    cp: (index: Int, paramName: String) -> String,
    cc: (index: Int, content: String) -> String,
    grb: () -> String,
    private val tfn: (String) -> String
) : AbstractFunctionTransformer(cp = cp, cc = cc, grb = grb) {
    override fun transform(kotlinFunctionInfo: KotlinFunctionInfo): LanguageFunctionDefinition {
        val fn: Int = kotlinFunctionInfo.parameterCount
        val index = kotlinFunctionInfo.index
        var paramSize = 0
        val parameterForm = tfn(kotlinFunctionInfo.name)
        val definition = """
                    |def $parameterForm(${
            (1..fn).joinToString(transform = {
                changeParam(index + paramSize, "v$it").also { paramSize += 1 }
            })
        }): 
                    |    ${changeContent(index + paramSize, "pass").also { paramSize += 1 }}
                """.trimMargin("|")
        return LanguageFunctionDefinition(parameterForm, paramSize, definition)
    }
}