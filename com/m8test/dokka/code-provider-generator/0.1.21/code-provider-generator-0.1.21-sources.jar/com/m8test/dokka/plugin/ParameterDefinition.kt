package com.m8test.dokka.plugin

/**
 * Description TODO
 *
 * @date 2024/12/08 09:26:10
 * @author M8Test, contact@m8test.com, https://m8test.com
 */
data class ParameterDefinition(val name: String, val className: String, val hasReceiver: Boolean)