package com.m8test.dokka.plugin

/**
 * Description TODO
 *
 * @date 2024/10/11 18:05:26
 * @author M8Test, contact@m8test.com, https://m8test.com
 */

import org.jetbrains.dokka.base.DokkaBase
import org.jetbrains.dokka.pages.ContentPage
import org.jetbrains.dokka.pages.RootPageNode
import org.jetbrains.dokka.plugability.DokkaContext
import org.jetbrains.dokka.plugability.DokkaPlugin
import org.jetbrains.dokka.plugability.DokkaPluginApiPreview
import org.jetbrains.dokka.plugability.PluginApiPreviewAcknowledgement
import org.jetbrains.dokka.transformers.pages.PageTransformer
import java.util.Locale

class CustomUrlPlugin : DokkaPlugin() {
    val customUrlTransformer by extending {
        (plugin<DokkaBase>().htmlPreprocessors providing ::CustomUrlTransformer)
    }

    @DokkaPluginApiPreview
    override fun pluginApiPreviewAcknowledgement() = PluginApiPreviewAcknowledgement
}

class CustomUrlTransformer(context: DokkaContext) : PageTransformer {
    override fun invoke(input: RootPageNode): RootPageNode {
        return input.transformContentPagesTree { pageNode ->
            val result = pageNode.modified(name = pageNode.name.lowercase(Locale.getDefault()))
            result as ContentPage
        }
    }
}
